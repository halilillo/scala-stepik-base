package playground

object ScalaPlayground extends App {
  var aLong = 11
  aLong = 12
  println(aLong.getClass)

}
