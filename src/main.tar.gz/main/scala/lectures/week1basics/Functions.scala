package lectures.week1basics

object Functions extends App {

}
